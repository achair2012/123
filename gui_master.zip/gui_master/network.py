# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 13:18:42 2020

@author: 2007088
"""

import csv
import networkx as nx
import nltk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from draw import Figure_Canvas

def super_context(tokens,keyword,length):
    context = []
    for i in range(len(tokens)):
        for word in tokens[i]:
            if word == keyword:
                context.append(tokens[i-length:i+length+1])
                break
    return context




def draw(list1):
    read_tokens = []
    # 開啟 文本 檔案
    with open(list1[0],'r',newline='',encoding='UTF-8-sig') as csvf:
        rows = csv.reader(csvf)
        for row in rows:
            read_tokens.append(row)
    csvf.close()
    for token in read_tokens:
        if len(token) == 0:
            continue
        elif token[-1] == '':
            del(token[-1]) #去除一個尾巴的空
    
    keywords = []
    # 開啟 字詞庫 檔案
    if list1[6] == '中文':
        with open(list1[1],'r',encoding='big5') as csvf:
            rows = csv.reader(csvf)
            for row in rows:
                keywords.append(row)
        csvf.close()
        for token in keywords:
            while token[-1] == '':
                del(token[-1]) #去除一個尾巴的空格
    else:
        with open(list1[1],'r',encoding='UTF-8-sig') as csvf:
            rows = csv.reader(csvf)
            for row in rows:
                keywords.append(row)
        csvf.close()
        for token in keywords:
            while token[-1] == '':
                del(token[-1]) #去除一個尾巴的空格        
    
    searchlist = list1[2].split(',')
    nodes = []
    edges = []
    widths = []
    name_size = []
    allbag = []
    #計算前後文出現關鍵詞的頻率
    for bigword in searchlist:
        allbag.append([bigword,'關聯詞頻']) #輸出CSV用的
        a = super_context(read_tokens,bigword,int(list1[4]))
        imerge_token=[]
        for cell in a:
            for sent in cell:
                for word in sent:
                    imerge_token.append(word)
        
        freq = nltk.FreqDist(imerge_token)
        sort = sorted(freq.items(), key=lambda x: x[1],reverse = True)

    
        wordbag = {}
        #篩選出上下文高頻字中是CSR字詞庫中的詞者
        for cell in sort :
            for line in keywords:           
                if cell[0] in line and cell[0] != bigword:
                    switch = 0
                    for key,val in wordbag.items():
                        if key == line[3]:
                            val = val + cell[1]
                            switch = 1
                            break
                    if switch ==0:
                        wordbag.setdefault(line[3],cell[1])
                    break
    #計算整個文本中的字詞與頻率
        bag = {}
        imerge_token1=[]
        for sent in read_tokens:
            for token in sent:
                imerge_token1.append(token)
        freq2 = nltk.FreqDist(imerge_token1)
        sort2 =sorted(freq2.items(), key=lambda x: x[1],reverse = True)
        for cell1 in sort2:
            for line1 in keywords:
                if cell1[0] in line1:
                    switch1 = 0
                    for key,val in bag.items():
                        if key == line1[3]:
                            val = val + cell1[1]
                            switch1 = 1
                            break
                    if switch1 ==0:
                        bag.setdefault(line1[3],cell1[1])
                    break                
    
                
        sort1 = sorted(wordbag.items(), key=lambda x: x[1],reverse = True)
        for cell in sort1[:int(list1[3])]:
            nodes.append(cell[0])
            edges.append((bigword,cell[0]))
            widths.append(float(cell[1])/len(imerge_token)*1000)    
        nodes.append(bigword)    
    
        # 開啟 CSV 檔案

        sizes = []
        for words in nodes:
            for key,val in bag.items():
                if words == key:
                    sizes.append((words,int(val)*30)) #現在把字詞也丟進來
                    break
        name_size += sorted(set(sizes), key = sizes.index)
        
        for key,val in wordbag.items():
            allbag.append([key,str(val)])
        
        
        
        
    DG1 = nx.DiGraph()
    #XX = Figure_Canvas()
    
    DG1.add_nodes_from([w[0] for w in name_size])
    DG1.add_edges_from(edges)
    

    plt.figure(figsize=(50,50))
    pos1=nx.spring_layout(DG1)  #先創建每個節點的位置
    nx.draw(DG1, pos = pos1 ,with_labels=False,node_size=[w[1] for w in name_size],node_color = 'green',edge_color = 'gray', width=widths) #畫圖
    
    nx.draw_networkx_labels(DG1,pos1,font_size=18) #設定文字大小
    #中文顯示為框框請見:https://blog.csdn.net/cakecc2008/article/details/78905827
    plt.show()
    #return XX
    return allbag
#def saveCSV(bubble):
def saveCSV(list1,list2):
    with open(list1[5]+ "關聯詞.csv",'w',encoding="utf-8-sig", newline='') as csvFile:
        writer = csv.writer(csvFile)
        for cell in list2:
            writer.writerow(cell)
    csvFile.close()
    