# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 14:35:12 2020

@author: 2007088
"""
import sys
sys.path.append('C:\ProgramData\Anaconda3\Lib\gui_master')

import PyQt5.sip
import network
from PyQt5 import QtWidgets
from test686 import Ui_MainWindow
import Leaderanalysis
from PyQt5.QtWidgets import*
from PyQt5.QtCore import *
import text_process
import W2V

text_process_setting = ['','','-!@#$+——?【•】|“@”~●\d#……￥’･0-9%.%％，。``&>；''*,%，%〔’･〕:；�_()／/╱.’','']
sort1 = ['','']
fileName = ['none','none','']
BA_words = ['','','','','','']
parameter = ['','','','','','','none','','','']
similar_word=['','','']
bubble = ['','','','','','','']
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.comboBox_2.addItems(['','中文(請在環境資料夾放入dict.txt.big.txt字典)','英文'])
        self.ui.comboBox_2.currentIndexChanged.connect(self.language)
        
        self.ui.comboBox.addItems(['','CSR領域字詞庫','無字詞庫(單詞切割)'])
        self.ui.comboBox.currentIndexChanged.connect(self.dictionary)
        self.ui.lineEdit.setText('-!@#$+——?【•】|“@”~●\d#……￥0-9%.%％``&>；。''*,，%〔’･〕:；�_()／/╱.’')
        self.ui.pushButton_4.clicked.connect(self.sign)
        self.ui.pushButton_5.clicked.connect(self.save_data1)
        self.ui.pushButton_6.clicked.connect(self.text_process)
        
        
        self.ui.pushButton.clicked.connect(self.load_data1)
        self.ui.pushButton_2.clicked.connect(self.load_data2)
        self.ui.pushButton_3.clicked.connect(self.Leader_analysis)
        self.ui.comboBox_4.addItems(['請選擇語言','中文','英文'])
        self.ui.comboBox_4.currentIndexChanged.connect(self.language1)        
        self.ui.pushButton_8.clicked.connect(self.load_data3)
        self.ui.pushButton_9.clicked.connect(self.save_data2)
        self.ui.pushButton_7.clicked.connect(self.sort)
        
        self.ui.pushButton_10.clicked.connect(self.load_data4)
        self.ui.pushButton_15.clicked.connect(self.load_data5)
        self.ui.lineEdit_2.setText('')
        self.ui.lineEdit_3.setText('')
        self.ui.pushButton_13.clicked.connect(self.range1)
        self.ui.lineEdit_4.setText('')
        self.ui.pushButton_14.clicked.connect(self.length)
        self.ui.pushButton_11.clicked.connect(self.save_data3)
        self.ui.pushButton_12.clicked.connect(self.BA)
        
        #詞向量
        self.ui.comboBox_3.addItems(['','CBOW','skip-gram'])
        self.ui.comboBox_3.currentIndexChanged.connect(self.method)
        self.ui.lineEdit_5.setText('1')
        self.ui.lineEdit_6.setText('150')
        self.ui.lineEdit_7.setText('30')
        self.ui.lineEdit_8.setText('10')
        self.ui.lineEdit_9.setText('5')
        self.ui.pushButton_24.clicked.connect(self.parameter_set)
        self.ui.pushButton_16.clicked.connect(self.load_data6)
        self.ui.pushButton_17.clicked.connect(self.load_data7)
        self.ui.pushButton_19.clicked.connect(self.save_data4)
        self.ui.pushButton_23.clicked.connect(self.train)
        self.ui.pushButton_20.clicked.connect(self.savemodel)
        self.ui.pushButton_21.clicked.connect(self.load_data8)
        self.ui.lineEdit_10.setText('10')
        self.ui.pushButton_18.clicked.connect(self.similar_set)
        self.ui.pushButton_22.clicked.connect(self.similar_output)
        
        #關聯泡泡圖
        self.ui.pushButton_25.clicked.connect(self.load_data9)
        self.ui.pushButton_27.clicked.connect(self.load_data10)
        self.ui.pushButton_26.clicked.connect(self.bubble_draw)
        self.ui.pushButton_31.clicked.connect(self.save_data5)
        self.ui.pushButton_30.clicked.connect(self.save_csv)
        self.ui.comboBox_5.addItems(['請選擇語言','中文','英文'])
        self.ui.comboBox_5.currentIndexChanged.connect(self.language2)


    #文字處裡部分
    def language(self): #設定中英文
        text_process_setting[0] = self.ui.comboBox_2.currentText()
    def dictionary(self): #選擇要不要字詞庫
        text_process_setting[1] = self.ui.comboBox.currentText()
    def sign(self): #去除標點符號
        text_process_setting[2] = "'[" + self.ui.lineEdit.text() + "]'"
    def save_data1(self): #分詞存檔路徑
        directory = QFileDialog.getExistingDirectory(self,"儲存路徑","./")
        self.ui.label_10.setText(directory)
        self.ui.label_17.setText(directory +'/processed_content.csv')
        BA_words[0] = directory + '/processed_content.csv'
        text_process_setting[3] = directory + '/'

    def text_process(self): #分詞
        text_process.PDF_parsing(text_process_setting)
        self.ui.textBrowser_2.append('PDF文字萃取完成: pdf_content.txt')
        text_process.clean_process(text_process_setting)
        self.ui.textBrowser_2.append('文字分詞完成: processed_content.csv')
    def load_data3(self):  #詞坪計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_13.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字
            sort1[0] = fileName1
    def save_data2(self): #詞頻存檔路徑
        directory = QFileDialog.getExistingDirectory(self,"儲存路徑","./")
        self.ui.label_23.setText(directory)
        self.ui.label_25.setText(directory +'/sort_freq.csv')
        BA_words[1] = directory + '/sort_freq.csv'
        sort1[1] = directory + '/'
    def sort(self):
        text_process.sort_words(sort1)
        self.ui.textBrowser_2.append('詞頻計算完成: sort_freq.csv')
    def load_data4(self):  #前後文計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_17.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字
            BA_words[0] = fileName1
    def load_data5(self):  #前後文計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_25.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字
            BA_words[1] = fileName1
    def range1(self): #選擇前後文查找排名
        BA_words[2],BA_words[3] = self.ui.lineEdit_2.text(), self.ui.lineEdit_3.text()
        self.ui.textBrowser_2.append('排名設定完成')  
    def length(self): #璇則前後文查找長度
        BA_words[4] = self.ui.lineEdit_4.text()
        self.ui.textBrowser_2.append('上下文長度設定完成')
    def save_data3(self): #前後詞存檔路徑
        directory = QFileDialog.getExistingDirectory(self,"儲存路徑","./")
        self.ui.label_22.setText(directory)
        BA_words[5] = directory + '/'
    def BA(self):#執行前後文查找
        text_process.BA_words(text_process_setting[0],BA_words)
        self.ui.textBrowser_2.append('前後詞查找完成，請見目標資料夾')        
        
    #詞向量部分
    def method(self): #設定中英文
        if self.ui.comboBox_3.currentText() == 'CBOW':
            parameter[0] = 0
        elif self.ui.comboBox_3.currentText() == 'skip-gram':
            parameter[0] = 1
    def parameter_set(self):
        parameter[1] = int(self.ui.lineEdit_5.text())
        parameter[2] = int(self.ui.lineEdit_6.text())
        parameter[3] = int(self.ui.lineEdit_7.text())
        parameter[4] = int(self.ui.lineEdit_8.text())
        parameter[5] = int(self.ui.lineEdit_9.text())
        self.ui.textBrowser_3.append('參數設定完成')
    def load_data6(self):  #前後文計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*model);; (*.model)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_28.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字        
            parameter[6] = fileName1
    def load_data7(self):  #前後文計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_37.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字        
            parameter[7] = fileName1    
    def save_data4(self): #前後詞存檔路徑
        directory = QFileDialog.getExistingDirectory(self,"儲存路徑","./")
        self.ui.label_40.setText(directory)
        parameter[8] = directory + '/'
        similar_word[2] = directory + '/'
    def train(self):
        global model
        model = W2V.train(parameter)
        self.ui.textBrowser_3.append('模型建置完成')
    def savemodel(self):
        model.save(parameter[8] + 'word2vec_model.model')
        self.ui.textBrowser_3.append('模型輸出完成: word2vec_model.model')
    def load_data8(self):  #前後文計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*txt);; (*.txt)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_45.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字        
            similar_word[0] = fileName1    
    def similar_set(self):
        similar_word[1] = self.ui.lineEdit_10.text()
    def similar_output(self):
        W2V.output(similar_word,model)
        self.ui.textBrowser_3.append('關鍵字相似詞輸出完成: similar_words.csv')
     
     #關聯度泡泡圖
    def load_data9(self):  #前後文計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_44.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字        
            bubble[0] = fileName1        
    def load_data10(self):  #前後文計算輸入檔
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_51.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字        
            bubble[1] = fileName1
    def language2(self): #選擇要不要字詞庫
        bubble[6] = self.ui.comboBox_5.currentText()
    def bubble_draw(self):
        bubble[2] = self.ui.lineEdit_11.text()
        bubble[3] = int(self.ui.lineEdit_12.text()) 
        bubble[4] = int(self.ui.lineEdit_13.text()) 
        #graphicscene1 = QtWidgets.QGraphicsScene()  # 第三步，创建一个QGraphicsScene，因为加载的图形（FigureCanvas）不能直接放到graphicview控件中，必须先放到graphicScene，然后再把graphicscene放到graphicview中
        #graphicscene1.addWidget(network.draw(bubble))
        #self.ui.graphicsView_2.setScene(graphicscene1)  # 第五步，把QGraphicsScene放入QGraphicsView
        #self.ui.graphicsView_2.show() 
        global llll
        llll = network.draw(bubble)
        print("done")
        self.ui.textBrowser_4.append('關聯度泡泡圖輸出完成，請見彈出視窗')
        self.ui.textBrowser_4.append('若要儲存圖片，請利用彈出視窗的儲存鍵')
    def save_data5(self): #前後詞存檔路徑
        directory = QFileDialog.getExistingDirectory(self,"儲存路徑","./")
        self.ui.label_55.setText(directory)
        parameter[8] = directory + '/'
        bubble[5] = directory + '/'
    def save_csv(self):
        network.saveCSV(bubble,llll)
        self.ui.textBrowser_4.append('CSV檔輸出完成: 關聯詞.csv')
    #比較分析部分
    def load_data1(self): #讀
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_3.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字
            fileName[0] = fileName1
    def load_data2(self):
        fileName1, filetype = QFileDialog.getOpenFileName(self,"開啟檔案","./","(*csv);; (*.csv)") #最後兩個參數表示只允許顯示 選擇csv檔
        if fileName1 != '':
            self.ui.label_4.setText(fileName1)#選好檔案之後把"choose a file"換成檔案的名字
            fileName[1] = fileName1
    def language1(self): #選擇要不要字詞庫
        fileName[2] = self.ui.comboBox_4.currentText()
    def Leader_analysis(self):
        company_words, leader_words = Leaderanalysis.get_data(fileName)
        ms, d, dt = Leaderanalysis.Leaderanalysis(company_words,leader_words,'company')
        
        graphicscene = QtWidgets.QGraphicsScene()  # 第三步，创建一个QGraphicsScene，因为加载的图形（FigureCanvas）不能直接放到graphicview控件中，必须先放到graphicScene，然后再把graphicscene放到graphicview中
        graphicscene.addWidget(Leaderanalysis.draw_Leaderanalysis(d,dt,0.4,'company'))
        self.ui.graphicsView.setScene(graphicscene)  # 第五步，把QGraphicsScene放入QGraphicsView
        self.ui.graphicsView.show() 
        self.ui.graphicsView.setFixedSize(600,400)
        #輸出缺乏關鍵字
        for cell in ms:
            for i in range(len(cell)):
                if i == 2:
                    continue
                self.ui.textBrowser.append(str(cell[i]) + ',')
            self.ui.textBrowser.append('--------------------------------------')


if __name__ == '__main__':
     app = QtWidgets.QApplication([])
     window = MainWindow()
     window.show()
     sys.exit(app.exec_())