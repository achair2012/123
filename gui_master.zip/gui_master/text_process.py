# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 10:34:14 2020

@author: 2007088
"""
import fitz
import os 
import csv
import nltk
import jieba
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer
import re
from nltk.tokenize import MWETokenizer
from nltk.corpus import stopwords

#還原詞態用
def get_wordnet_pos(tag):
    if tag.startswith('J'):
        return wordnet.ADJ
    elif tag.startswith('V'):
        return wordnet.VERB
    elif tag.startswith('N'):
        return wordnet.NOUN
    elif tag.startswith('R'):
        return wordnet.ADV
    else:
        return None


def PDF_parsing(list):
    path = 'D://pdf_file//'  #File Folder Path
    FileList = os.listdir(path)
    pdf_content = []
    for index,value in enumerate(FileList):
        pdf = fitz.open ( path + value )
        print(value)
        for currentpage in range ( pdf.pageCount ):   
            pdf_content.append(pdf.loadPage(currentpage).getText())
    fp = open(list[3] + "\pdf_content.txt", "w",encoding="utf-8-sig")
    fp.writelines(pdf_content)
    fp.close()

def clean_process(list1):
    file = open(list1[3] + "\pdf_content.txt",encoding="utf-8")
    text1 = file.read()
    #需要中英文分開的部分
    if list1[0] == '英文':
        sentences = nltk.sent_tokenize(text1) #斷句
        tokens = [nltk.word_tokenize(sent) for sent in sentences] #斷詞
        #英文轉小寫
        for sent in tokens:
            for i in range(len(sent)):
                sent[i] = sent[i].lower()
        pos1 = [nltk.pos_tag(sent) for sent in tokens]
        wnl = WordNetLemmatizer()
        lemmas_sent = []
        #還原詞態
        for sent in pos1:
            cell = []
            for word,tag in sent:
                wordnet_pos = get_wordnet_pos(tag) or wordnet.NOUN
                cell.append(wnl.lemmatize(word, pos=wordnet_pos))
            lemmas_sent.append(cell)
    elif list1[0] == '中文(請在環境資料夾放入dict.txt.big.txt字典)':
        #中文讀通用辭典
        jieba.set_dictionary('dict.txt.big.txt')
        #中文讀領域辭典
        if list1[1] == 'CSR領域字詞庫':
            jieba.load_userdict('CHdist.txt')
        #中文分句    
        sentences = re.split("[；。，]", text1)
        #中文分詞
        tokens = []
        for sent1 in sentences:
            tokens.append([','.join(list(jieba.cut(sent1,cut_all=False, HMM=True)))])
        lemmas_sent = []
        for sent in tokens:
            lemmas_sent.append(sent[0].split(','))
    #去除符號        
    for sent2 in lemmas_sent: 
        for i in range(len(sent2)):
            sent2[i] = re.sub(list1[2],'', sent2[i])

    
    if list1[0] == '英文':
        if list1[1] == 'CSR領域字詞庫':
            #連結英文專有名詞
            pn_list = [word.strip('\n').split(',')  for word in open('proper noun.csv') ] #proper noun.csv為輸入專有名詞的地方
            for cell in pn_list:
                while cell[-1] == '':
                    del cell[-1]
            tokenizer = MWETokenizer(pn_list)
            pn_tokens =[]
            for sent in lemmas_sent:
                pn_tokens.append(tokenizer.tokenize(sent))
        else:
            pn_tokens = lemmas_sent
    
    #中文去除停止詞
    if list1[0] == '中文(請在環境資料夾放入dict.txt.big.txt字典)':
        stopword = [w.strip('\n') for w in open('停用詞-繁體中文.txt',encoding="utf-8-sig")]   
        done_tokens =[]
        for sent3 in lemmas_sent:
            if len(sent3) > 1:
                done_tokens.append([word for word in sent3 if (len(word) > 1 and word != '' and word != '\n' and word != '' and word != '\t' and word != '。' and word != ' ' and word not in stopword)])

    if list1[0] == '英文':   
        #去除英文停止詞
        stopwords.words('english')
        clean_tokens =[]
        for sent in pn_tokens:
            if len(sent) > 1:
                clean_tokens.append([word for word in sent if (word not in stopwords.words('english') and word !='' and word != '-')])
        #根據觀察結果額外處理:目前為而外去除不知道為啥沒被去掉的符號，以及去掉單一字母的字
        done_tokens = []
        for sent in clean_tokens:
            done_tokens.append([word for word in sent if (len(word) > 2 and word !="'" and word != "''" and word !="；" and
                                word !="our" and word !="they")])
    #檔案輸出
    with open(list1[3] + 'processed_content.csv', 'w',encoding="UTF-8-sig") as f:
        for line in done_tokens[:]:
            for word in line:
                f.writelines(word +',')
            f.writelines("\n")
    f.close()
def sort_words(list2):
    read_tokens = []
    # 開啟 CSV 檔案
    with open(list2[0],'r',newline='',encoding='UTF-8-sig') as csvf:
        rows = csv.reader(csvf)
        for row in rows:
            read_tokens.append(row)
    csvf.close()
    for token in read_tokens:
        if len(token) == 0:
            continue
        elif token[-1] == '':
            del(token[-1]) #去除一個尾巴的空格
    imerge_token=[]
    for sent in read_tokens:
        for token in sent:
            imerge_token.append(token)
    freq = nltk.FreqDist(imerge_token)
    sort = sorted(freq.items(), key=lambda x: x[1],reverse = True)
    
    with open(list2[1]+'sort_freq.csv', 'w',encoding="UTF-8-sig", newline='') as f:
        for line in sort:
            f.writelines(line[0]+',' + str(line[1]) +'\n')
    f.close()
#找前後文用函數
def __is_bounded(direction,range,index,tokens_leng):
    cover = range*direction
    if cover+index<0 or cover+index >= tokens_leng:
        return True
    else:
        return False
def find(Language,keyword,text,window_size):
    all_down = []
    all_up = []
    all_middle = []
    for sent in text:
        if keyword in sent:
            d,u,m = get_context(Language,keyword,sent, window_size)
            all_down = all_down + d
            all_up = all_up + u
            all_middle = all_middle + m
    return all_down,all_up,all_middle
def get_context(L,keyword,sent, window_size):
    down_text = []
    up_text = []  
    middle_text = []
    for i, token in enumerate(sent):
        if L == '英文':
            if token == keyword:
                if not __is_bounded(1,window_size,i,len(sent)):
                    consist = str(sent[i])
                    for j in range(1,window_size+1):
                        consist = consist + ' ' + str(sent[i+j])
                    down_text.append((consist))
                if not __is_bounded(-1,window_size,i,len(sent)):
                    consist = str(sent[i-window_size])
                    for j in range(1,window_size+1):
                        consist = consist + ' ' + str(sent[i-window_size+j])
                    up_text.append((consist))
                if not __is_bounded(-1,window_size,i,len(sent)) and not __is_bounded(1,window_size,i,len(sent)):
                    consist = str(sent[i-window_size])
                    for j in range(1,window_size*2+1):
                        consist = consist + ' ' + str(sent[i-window_size+j])
                    middle_text.append((consist))                
        if L == '中文(請在環境資料夾放入dict.txt.big.txt字典)':
            if token == keyword:
                if not __is_bounded(1,window_size,i,len(sent)):
                    consist = str(sent[i])
                    for j in range(1,window_size+1):
                        consist = consist + str(sent[i+j])
                    down_text.append((consist))
                if not __is_bounded(-1,window_size,i,len(sent)):
                    consist = str(sent[i-window_size])
                    for j in range(1,window_size+1):
                        consist = consist  + str(sent[i-window_size+j])
                    up_text.append((consist))
                if not __is_bounded(-1,window_size,i,len(sent)) and not __is_bounded(1,window_size,i,len(sent)):
                    consist = str(sent[i-window_size])
                    for j in range(1,window_size*2+1):
                        consist = consist  + str(sent[i-window_size+j])
                    middle_text.append((consist))         
    return down_text,up_text,middle_text
def freq_cal(list5):
    freq = nltk.FreqDist(list5)
    sort = sorted(freq.items(), key=lambda x: x[1],reverse = True)
    return sort



def BA_words(language,list3):
    read_tokens1 = []
    # 開啟文本CSV 檔案
    with open(list3[0],'r',newline='',encoding='UTF-8-sig') as csvf:
        rows = csv.reader(csvf)
        for row in rows:
            read_tokens1.append(row)
    csvf.close()
    for token in read_tokens1:
        if len(token) == 0:
            continue
        elif token[-1] == '':
            del(token[-1])   
    #開啟詞頻排序檔案
    freq_word = [w.strip('\n').strip('\ufeff').split(',') for w in open(list3[1],encoding="utf-8-sig")]
    
    for i in range(int(list3[2])-1,int(list3[3])):
        kw = freq_word[i]
        u,d,m = find(language,kw[0],read_tokens1,int(list3[4]))
        us,ds,ms = freq_cal(u),freq_cal(d),freq_cal(m)
        with open(list3[5] + str(i+1) + "_"  + str(kw[0])+ "_" + str(list3[4]) + ".csv",'w',encoding="utf-8-sig", newline='') as csvFile:
            writer = csv.writer(csvFile)
            
            writer.writerow(['up','frequence'])
            for cell in us:
                writer.writerow(cell)
                
            writer.writerow('\n')
            writer.writerow(['down','frequence'])
            for cell in ds:
                writer.writerow(cell)
                
            writer.writerow('\n')
            writer.writerow(['middle','frequence'])
            for cell in ms:
                writer.writerow(cell)
        csvFile.close()
