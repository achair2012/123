# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 08:31:02 2020

@author: 2007088
"""

import csv
import matplotlib.pyplot as plt
from draw import Figure_Canvas
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

def get_data(filename):
    company_file = filename[0]
    Leader_file = filename[1]
    C_words = []
    with open(company_file,'r',encoding='UTF-8-sig') as csvf:
        rows = csv.reader(csvf)
        for row in rows:
            C_words.append(row)
    csvf.close()
    L_words = []
    if filename[2] == '英文':     
        with open(Leader_file,'r',encoding='UTF-8-sig') as csvf:
            rows = csv.reader(csvf)
            for row in rows:
                L_words.append(row)
        csvf.close()    
        for token in L_words:
            while token[-1] == '':
                del(token[-1])
    elif filename[2] == '中文':
    
        with open(Leader_file,'r',encoding='big5') as csvf:
            rows = csv.reader(csvf)
            for row in rows:
                L_words.append(row)
        csvf.close()    
        for token in L_words:
            while token[-1] == '':
                del(token[-1])
    return C_words, L_words

def Leaderanalysis(company_words,leader_words,companyname):
    only_words = []
    for cell in company_words:
        only_words.append(cell[0])
    E_total = 0
    S_total = 0
    G_total = 0
    N_total = 0
    for cell in leader_words:
        if cell[0] =='E':
            E_total+=1
        if cell[0] =='S':
            S_total+=1 
        if cell[0] =='G':
            G_total+=1
        if cell[0] =='N':
            N_total+=1
    dic_total = {'E_total':E_total,'S_total':S_total,"G_total":G_total,"N_total":N_total}
    dic = {'E':0,'S':0,"G":0,"N":0}
            
    missing_words = []
    for cell in leader_words:
        switch1 = 0
        for word in cell[2:]:
            if word in only_words:
                dic[str(cell[0])] +=1
                switch1 = 1
                break
        if switch1 == 0:
            missing_words.append(cell)
    return missing_words, dic, dic_total 

def draw_Leaderanalysis(dic,dic_total,width,companyname):
    #畫圖
    #A = plt.bar([i-width/2 for i in range(len(dic))],dic.values(), width=width,label=companyname)
    #B = plt.bar([i+width/2 for i in range(len(dic))], dic_total.values(), width=width,label='Leader')
    dr = Figure_Canvas()
    

    A = dr.axes.bar([i+width/2 for i in range(len(dic))], dic_total.values(), width=width,label='Leader')
    B = dr.axes.bar([i-width/2 for i in range(len(dic))],dic.values(), width=width,label=companyname)
    dr.axes.set_xticks([0,1,2,3]) #設定你label放哪
    dr.axes.set_xticklabels(['E','S','G','N']) #設定你label是啥
    createLabels(A,dr)
    createLabels(B,dr) 
    
    #plt.legend()
    #plt.show()
    return dr

def createLabels(data,t):                   # 自定義函數，為引用plusone團隊
    for item in data:
        height = item.get_height()
        t.axes.text(
            item.get_x()+item.get_width()/2., 
            height*1.05, 
            '%d' % int(height),
            ha = "center",
            va = "bottom",
        )