# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 10:11:46 2020

@author: 2007088
"""

from gensim.models.word2vec import Word2Vec
import pandas as pd
import csv

def most_similar(w2v_model, words, topn=10):
    similar_df = pd.DataFrame()
    for word in words:
        try:
            similar_words = pd.DataFrame(w2v_model.wv.most_similar(word, topn=topn), columns=[word, 'cos'])
            similar_df = pd.concat([similar_df, similar_words], axis=1)
        except:
            print(word, "not found in Word2Vec model!")
    return similar_df



def train(list1):
    read_tokens = []
    # 開啟 CSV 檔案
    with open(list1[7],'r',newline='',encoding='UTF-8-sig') as csvf:
        rows = csv.reader(csvf)
        for row in rows:
            read_tokens.append(row)
    csvf.close()
    for token in read_tokens:
        if len(token) == 0:
            continue
        elif token[-1] == '':
            del(token[-1]) #去除一個尾巴的空格
            
            
    if list1[6] != 'none':
        model = Word2Vec.load(list1[6])
    else:
        model = Word2Vec(read_tokens,sg = list1[0],window=list1[1], size=list1[2],min_count=list1[3],iter=list1[4],negative=list1[5])
    return model

def output(list2,model1):
    with open(list2[0], 'r',encoding="UTF-8") as k:
        keywords = k.read().strip('\ufeff').split("\n")
    k.close()
    similar_wordset = most_similar(model1, keywords)
    similar_wordset.to_csv(list2[2] + 'similar_words.csv',encoding="UTF-8-sig")

    